# CHATGPT_BOOTSTRAP.md

## Purpose

Use this file at the beginning of any new ChatGPT conversation about LEAP.

This file gives ChatGPT enough durable context to continue without relying on old chat history.

## Project Identity

LEAP is an AI-assisted literate-programming framework that transforms enterprise codebases into interactive, explainable, auditable KPI Bluebooks.

LEAP is not merely documentation, visualization, or reporting.

LEAP is:

- a KPI correctness engine,
- a governance system,
- an explainable enterprise layer,
- an executable knowledge system.

## Research Identity

LEAP is grounded in literate programming, program comprehension, explainable systems, software traceability, knowledge engineering, and enterprise governance.

Core research idea:

> Transform executable systems into interpretable knowledge systems.

## Development Memory

The repository contains an `.ai` folder, also called `mrAI`, which acts as the shared memory and context-governance layer for AI agents.

Conversation history is not shared memory.

The project remembers itself through `.ai`.

## Current Engineering Philosophy

Use the Cheapkeeper Strategy Algorithm (CSA):

1. Use Gemini/Copilot/Cascade first.
2. Use Codex only for difficult diagnosis or final review.
3. Externalize important findings into `.ai`.
4. Never pay twice for the same understanding.

## Current Phases

- Phase 1 — System Foundation: complete.
- Phase 2 — KPI Discovery & Extraction: complete, improvements later.
- Phase 3 — Governance & Validation: logic exists, enhancement pending.
- Phase 4A — UI Stability & Layout Recovery: active.
- Phase 4B — Governance Intelligence & Behavior Control: after Phase 4A.
- Phase 5 — Interactive Enterprise Experience: locked.
- Phase 6 — Agentic Literate Programming: future research direction.

## Current Active Focus

Phase 4A:

- restore stable enterprise KPI page UI,
- fix right sidebar regression,
- restore warning/review queue design,
- ensure footer visibility,
- ensure Sphinx and LEAP layout cooperate,
- preserve actual backend generation pipeline.

## Non-Negotiable Rules

Do not:

- hardcode generated HTML,
- patch generated `_build` artifacts,
- bypass Sphinx,
- remove governance logic,
- remove traceability,
- remove alerts to hide problems,
- silently delete sidebar sections,
- certify AI-generated interpretation as truth.

Always preserve:

- evidence mapping,
- deterministic behavior,
- source-code lineage,
- governance and auditability,
- enterprise usability.
