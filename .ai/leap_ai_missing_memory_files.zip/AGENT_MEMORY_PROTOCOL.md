# AGENT_MEMORY_PROTOCOL.md

## Purpose

This file defines how AI agents communicate through `.ai`.

## Core Principle

Reasoning is not memory.

Only externalized, written, durable information in `.ai` counts as shared memory.

## Mandatory Workflow

### 1. Read

Every agent begins with:

```text
Read `.ai/START_HERE.md`.
```

The agent then reads task-relevant memory files.

### 2. Diagnose

For bugs or regressions, the agent must identify:

- root cause hypothesis,
- affected subsystem,
- files to inspect,
- safe plan,
- verification strategy.

### 3. Externalize

Any durable finding must be written into `.ai`.

Examples:

- root cause,
- architectural decision,
- regression cause,
- implementation plan,
- unresolved risk,
- completed verification.

### 4. Implement

Only after the diagnosis is externalized should implementation begin.

### 5. Verify

Every implementation must include verification evidence.

Examples:

- command run,
- output summary,
- generated file checked,
- browser/manual check,
- test result.

### 6. Handoff

At the end, update:

- HANDOFF.md,
- CHANGELOG.md,
- CURRENT_STATE.md,
- BUGS.md when needed,
- PHASE_LOG.md when phase status changes.

## Required Final Agent Report

Before finishing, every agent must report:

1. Which `.ai` files were modified.
2. What changed.
3. Why it changed.
4. Verification evidence.
5. Whether shared memory was updated.

If no memory was updated, state:

> Shared memory was NOT updated.

## Forbidden

Agents must not:

- claim files were updated without showing evidence,
- rely only on chat history,
- hide risks,
- invent completed work,
- delete context to simplify the task.
