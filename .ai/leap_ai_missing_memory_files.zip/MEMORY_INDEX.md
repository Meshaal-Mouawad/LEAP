# MEMORY_INDEX.md

## Purpose

This file helps humans and agents know which `.ai` file to read for which task.

## Core Files

| File | Purpose |
|---|---|
| START_HERE.md | Mandatory entry point |
| CHATGPT_BOOTSTRAP.md | Start new ChatGPT conversations |
| RESEARCH_CONTEXT.md | PhD and scientific identity |
| PROJECT_CONTEXT.md | What LEAP does |
| ARCHITECTURE.md | How LEAP works |
| SYSTEM_BEHAVIOR_SPEC.md | System-level behavior requirements |
| GOVERNANCE_SPEC.md | Governance requirements |
| UI_BEHAVIOR_SPEC.md | UI and alert behavior |
| BUSINESS_RULES.md | Business constraints |
| CURRENT_STATE.md | Current work |
| PHASE_LOG.md | Phase roadmap |
| HANDOFF.md | Previous agent summary |
| BUGS.md | Known risks |
| DECISIONS.md | Decisions |
| CHANGELOG.md | Change history |
| AGENT_MEMORY_PROTOCOL.md | How agents share memory |
| AGENT_CHAT_ROLES.md | How to split conversations |
| SESSIONS/ | Long-session summaries |

## Which file should I update?

### New bug

Update:

- BUGS.md
- HANDOFF.md
- CURRENT_STATE.md

### New decision

Update:

- DECISIONS.md
- HANDOFF.md
- CHANGELOG.md

### Phase change

Update:

- PHASE_LOG.md
- CURRENT_STATE.md
- HANDOFF.md

### UI rule

Update:

- UI_BEHAVIOR_SPEC.md
- DECISIONS.md if it is a major design decision

### Governance rule

Update:

- GOVERNANCE_SPEC.md
- BUSINESS_RULES.md if business-critical

### Research idea

Update:

- RESEARCH_CONTEXT.md
- ROADMAP.md
- DECISIONS.md if accepted
