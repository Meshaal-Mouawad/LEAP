# AGENT_CHAT_ROLES.md

## Purpose

This file defines how separate ChatGPT conversations or AI agents should specialize while sharing the same `.ai` memory.

## Recommended ChatGPT Conversations

### 1. LEAP Development Chat

Purpose:

- debugging,
- Flask/Sphinx pipeline,
- KPI extraction,
- governance implementation,
- mrAI maintenance.

Reads:

- START_HERE.md
- PROJECT_CONTEXT.md
- ARCHITECTURE.md
- SYSTEM_BEHAVIOR_SPEC.md
- GOVERNANCE_SPEC.md
- UI_BEHAVIOR_SPEC.md
- CURRENT_STATE.md
- HANDOFF.md
- BUGS.md
- PHASE_LOG.md

Writes:

- HANDOFF.md
- CHANGELOG.md
- BUGS.md
- CURRENT_STATE.md
- PHASE_LOG.md

### 2. LEAP UI/UX Design Chat

Purpose:

- enterprise UI,
- government-ready UX,
- Bluebook interaction design,
- KPI Knowledge Dossier layout,
- sidebar/warning design,
- developer experience.

Reads:

- START_HERE.md
- UI_BEHAVIOR_SPEC.md
- SYSTEM_BEHAVIOR_SPEC.md
- RESEARCH_CONTEXT.md
- PHASE_LOG.md

Writes:

- UI_BEHAVIOR_SPEC.md
- DECISIONS.md
- PHASE_LOG.md
- HANDOFF.md

### 3. LEAP Research Chat

Purpose:

- PhD writing,
- literate programming,
- executable knowledge systems,
- research contribution,
- methodology,
- dissertation figures.

Reads:

- RESEARCH_CONTEXT.md
- CHATGPT_BOOTSTRAP.md
- SYSTEM_BEHAVIOR_SPEC.md
- DECISIONS.md
- PHASE_LOG.md

Writes:

- RESEARCH_CONTEXT.md
- DECISIONS.md
- ROADMAP.md

### 4. LEAP mrAI / Agentic AI Chat

Purpose:

- `.ai` architecture,
- shared context governance,
- Agentic Literate Programming,
- CSA,
- multi-agent orchestration.

Reads:

- START_HERE.md
- CHATGPT_BOOTSTRAP.md
- AGENT_MEMORY_PROTOCOL.md
- DECISIONS.md
- ROADMAP.md

Writes:

- AGENT_MEMORY_PROTOCOL.md
- DECISIONS.md
- ROADMAP.md
- PHASE_LOG.md

## Rule

Each chat specializes, but all chats must use the same `.ai` folder as the source of truth.

No chat should rely on private conversation history as project memory.
