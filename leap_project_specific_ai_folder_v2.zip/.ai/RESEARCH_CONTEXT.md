# LEAP AXIS — RESEARCH_CONTEXT.md

## Purpose

This file defines the research identity of Leap. It answers: **Why does Leap exist?**

This file should change rarely. It protects the PhD and scientific direction of the project.

## Scientific problem

Leap solves the semantic disconnect between executable systems and business meaning.

In modern enterprise systems:

- KPIs are embedded in code.
- Logic is distributed across modules.
- Decision rules are implicit.
- Business stakeholders cannot interpret code.
- Engineers often cannot express implementation logic in business language.

This creates a traceability, interpretability, and governance problem.

## Research hypothesis

If program logic can be systematically extracted, interpreted, and structurally organized into narrative form, then enterprise systems become more explainable, auditable, governable, and maintainable.

## Research novelty

Leap introduces this transformation paradigm:

```text
Code → Semantic Structure → Knowledge Representation → Narrative Blue Book
```

Novel aspects:

- KPI as a computable semantic unit.
- Dual-perspective representation: business + developer.
- Deterministic explainability.
- Automatic narrative synthesis from source code.
- Evidence-backed Blue Book generation.

## Foundational paradigms

Leap builds on and integrates:

- Literate Programming
- Explainable Systems
- Software Traceability
- Knowledge Engineering
- Program Comprehension
- Reverse Engineering
- Enterprise Architecture
- Model-Driven Engineering

## Knowledge gap

Business teams think in meaning, KPIs, decisions, governance, and accountability.

Engineering teams think in code, functions, modules, pipelines, and databases.

The gap is that business asks “What does this KPI mean?” while engineering answers “It is computed in module X using logic Y.” There is usually no unified representation both sides can use.

## How Leap reduces the gap

Leap creates a bidirectional semantic bridge:

```text
Code → Extract → Annotate → Explain → Present
```

Outputs include business-readable meaning, developer-level traceability, formula evidence, code lineage, governance metadata, and reviewable Blue Book narrative.

## Limitations of existing approaches

| Approach | Limitation |
|---|---|
| Documentation tools | Static and manual |
| BI dashboards | No code lineage |
| Data catalogs | Disconnected from execution |
| Explainable AI | Usually focused on ML, not deterministic enterprise systems |
| Code comments | Local, inconsistent, and not governed |

## Scientific contributions

- KPI extraction formalizes KPI discovery from code structures.
- Blue Book generation introduces executable documentation.
- Governance exposes conflicts between business definition and actual execution.
- Traceability maps `KPI → Formula → Code → Line Number`.
- Interactive navigation supports business and developer perspectives.

## Enterprise contributions

Leap supports transparency, onboarding, audit readiness, KPI standardization, reduced hidden expert dependency, and governed knowledge transfer.

## PhD contributions

1. A new paradigm: executable knowledge systems.
2. A transformation model: `Code → Knowledge → Narrative`.
3. Formalization of KPIs as semantic units.
4. A deterministic explainability framework for enterprise systems.
5. A governed bridge between technical implementation and business understanding.

## Future research directions

- NLP-enhanced semantic enrichment.
- Real-time computation tracing.
- Cross-system knowledge graphs.
- Autonomous governance systems.
- KPI reasoning and simulation.
- Multi-agent shared memory for software engineering.

## Long-term vision

Leap becomes the operating system for enterprise knowledge: no KPI is opaque, no logic is hidden, and every decision is traceable.

## Why Leap is not a documentation generator

| Traditional documentation | Leap |
|---|---|
| Manual | Automated |
| Static | Executable |
| Descriptive | Evidence-based |
| Separate from code | Derived from code |
| Hard to audit | Traceable |

Leap is a system cognition layer.

## Immutable principles

1. Code first.
2. Determinism.
3. Dual representation: business meaning + developer lineage.
4. Evidence-based output.
5. Structural traceability.
6. Human-readable and machine-readable output.
7. No hidden logic.
8. AI enrichment is draft unless human-approved.
9. Missing evidence must be marked, not invented.

## Final research statement

Leap is not merely a tool. It is a scientific framework that transforms executable systems into interpretable knowledge systems.
